import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-schedule-aside',
  templateUrl: './schedule-aside.component.html',
  styleUrls: ['./schedule-aside.component.scss']
})
export class ScheduleAsideComponent implements OnInit {
  constructor() {}

  ngOnInit() {
  }
}
